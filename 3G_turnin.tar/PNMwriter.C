#include <PNMwriter.h>
#include <image.h>
//not used but still including..Would have liked to asked if this is 
//standard to include because I could see myself writing future methods
//if necessary

